<?php
require('config/Database.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['do-login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $connect = openConnection();
        $query = "SELECT * FROM users WHERE username = '$username'";
        $result = mysqli_query($connect, $query);

        if (mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            if (password_verify($password, $user['password'])) {
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                if ($user['role'] == 'admin') {
                    header('Location: admin-dashboard.php');
                } else {
                    header('Location: user-dashboard.php');
                }
                exit;
            } else {
                header('Location: index.php?notify=error');
            }
        } else {
            header('Location: index.php?notify=error');
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/signin.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Masuk</title>
</head>
<body class="text-center">
    <div class="container">
        <form action="index.php" method="POST" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Masuk</p>
            <div class="input-group">
                <input type="text" placeholder="Username" id="inputEmail" name="username" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Password" id="inputPassword" name="password" required>
            </div>
            <?php if (isset($_GET['notify']) && $_GET['notify'] == 'error') { ?>
                <p class="text-danger">Username atau password salah</p>
            <?php } ?>
            <div class="input-group">
                <button name="do-login" class="btn btn-primary">Masuk</button>
            </div>
            <p class="mt-3">Belum punya akun? <a href="register.php">Daftar di sini</a></p>
            <p class="mt-3">Lupa password? <a href="forgot-password.php">Klik di sini</a></p>
        </form>
    </div>
</body>
</html>
