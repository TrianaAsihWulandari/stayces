<?php
require('config/Database.php');
require('config/Email.php'); // Include the Email configuration file
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $nama_toko = $_POST['nama_toko'];
  $username = $_POST['username'];
  $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
  $email = $_POST['email']; // Ambil email dari form
  $role = 'user';
  $verification_code = md5(uniqid($username, true)); // Generate a unique verification code

  $connect = openConnection();
  $query = "INSERT INTO users (nama_toko, username, password, email, role, verification_code, is_verified) VALUES ('$nama_toko', '$username', '$password', '$email', '$role', '$verification_code', 0)";

  if (mysqli_query($connect, $query)) {
    // Kirim email verifikasi
    $verification_link = "http://localhost:8000/verify.php?code=$verification_code";
    $subject = "Verifikasi Akun Anda";
    $message = "Klik link berikut untuk memverifikasi akun Anda: $verification_link";
    $headers = "From: no-reply@yourdomain.com";

    if (mail($email, $subject, $message, $headers)) {
      header('Location: check_email.php'); // Halaman yang memberi tahu pengguna untuk memeriksa email
    } else {
      $error = "Gagal mengirim email verifikasi. Silakan coba lagi.";
    }
  } else {
    $error = "Gagal mendaftar. Silakan coba lagi.";
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Daftar</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css" />
</head>
<body>
  <div class="container mt-5">
    <h2>Daftar</h2>
    <?php if (isset($error)) { echo "<div class='alert alert-danger'>$error</div>"; } ?>
    <form action="register.php" method="POST">
      <div class="mb-3">
        <label for="nama_toko" class="form-label">Nama Toko</label>
        <input type="text" class="form-control" id="nama_toko" name="nama_toko" required>
      </div>
      <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" class="form-control" id="username" name="username" required>
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" required>
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password" required>
      </div>
      <button type="submit" class="btn btn-primary">Daftar</button>
    </form>
    <p class="mt-3">Sudah punya akun? <a href="index.php">Login di sini</a></p>
  </div>
</body>
</html>
