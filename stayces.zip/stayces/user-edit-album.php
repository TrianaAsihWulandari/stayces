<?php

require('config/Database.php');
require('helpers/PreventInjectionSQL.php');

$connection = openConnection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tahun = $_POST['tahun'];
    $nama_penyanyi = $_POST['nama_penyanyi'];
    $nama_album = $_POST['nama_album'];
    $versi_album = $_POST['versi_album'];
    $pendengar = $_POST['pendengar'];
    $jumlah = $_POST['jumlah_penjualan'];


    // Validasi dan sanitasi data jika perlu
    
    $query = "UPDATE album SET 
                tahun_penjualan = '$tahun',
                nama_penyanyi = '$nama_penyanyi',
                nama_album = '$nama_album',
                versi_album = '$versi_album',
                pendengar = '$pendengar',
                jumlah_penjualan = '$jumlah'
              WHERE id = '$id'";

  // Jalankan query dan periksa hasilnya
  if (mysqli_query($connection, $query)) {
    header('Location: user-tambah-album.php'); // Redirect ke halaman dashboard setelah berhasil mengupdate data
    exit();
} else {
    echo "Error: " . mysqli_error($connection); // Tampilkan kesalahan jika query gagal
}
}
