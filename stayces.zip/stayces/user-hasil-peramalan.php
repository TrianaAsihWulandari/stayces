<?php
require('config/Database.php');
require('libraries/RegresiLinier.php');

session_start();

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit();
}

$connect = openConnection();

if ($connect === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Mendapatkan data dari database
$query = 'SELECT tahun_penjualan, nama_penyanyi, nama_album, pendengar, jumlah_penjualan FROM album';
$result = mysqli_query($connect, $query);

$data = [];
$penyanyi = [];
$albums = [];
if ($result) {
    while ($obj = mysqli_fetch_object($result)) {
        $data[] = array(
            'tahun_penjualan' => $obj->tahun_penjualan,
            'nama_penyanyi' => $obj->nama_penyanyi,
            'nama_album' => $obj->nama_album,
            'pendengar' => $obj->pendengar,
            'jumlah_penjualan' => $obj->jumlah_penjualan,
            'x_squared' => pow((int) $obj->pendengar, 2),
            'y_squared' => pow((float) $obj->jumlah_penjualan, 2),
            'xy' => (int) $obj->pendengar * (float) $obj->jumlah_penjualan
        );

        // Menyimpan data penyanyi dan album untuk dropdown
        if (!isset($penyanyi[$obj->nama_penyanyi])) {
            $penyanyi[$obj->nama_penyanyi] = $obj->nama_penyanyi;
        }
        if (!isset($albums[$obj->nama_album])) {
            $albums[$obj->nama_album] = $obj->nama_album;
        }
    }
    mysqli_free_result($result);
} else {
    die("ERROR: Could not execute query: " . mysqli_error($connect));
}

if (count($data) > 0) {
    $x = array_column($data, 'pendengar');
    $y = array_column($data, 'jumlah_penjualan');
    
    $n = count($x);
    $sumX = array_sum($x);
    $sumY = array_sum($y);
    $sumX2 = array_sum(array_map(function($xi) {
        return pow($xi, 2);
    }, $x));
    $sumXY = array_sum(array_map(function($xi, $yi) {
        return $xi * $yi;
    }, $x, $y));

    // Hitung nilai a
    $numeratorA = ($sumY * $sumX2) - ($sumX * $sumXY);
    $denominatorA = ($n * $sumX2) - pow($sumX, 2);

    if ($denominatorA != 0) {
        $a = $numeratorA / $denominatorA;
        
        // Hitung nilai b
        $numeratorB = ($n * $sumXY) - ($sumX * $sumY);
        $denominatorB = ($n * $sumX2) - pow($sumX, 2);

        if ($denominatorB != 0) {
            $b = $numeratorB / $denominatorB;

    } else {
        $a = 0;
        $b = 0;
    }
}
}

$hasil_prediksi = '';
$stok_saran = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $tahun_prediksi = $_POST['tahun_prediksi'];
    $nama_penyanyi_prediksi = $_POST['nama_penyanyi_prediksi'];
    $nama_album_prediksi = $_POST['nama_album_prediksi'] ?? '';

    if (isset($b) && isset($a)) {
        // Ambil nilai pendengar dari data historis berdasarkan nama penyanyi dan album
        $nama_penyanyi_prediksi = mysqli_real_escape_string($connect, $nama_penyanyi_prediksi);
        $nama_album_prediksi = mysqli_real_escape_string($connect, $nama_album_prediksi);
        
        // Query untuk mendapatkan nilai pendengar dari database
        $query = "SELECT pendengar FROM album WHERE nama_penyanyi = '$nama_penyanyi_prediksi' AND nama_album = '$nama_album_prediksi' ORDER BY tahun_penjualan DESC LIMIT 1";
        $result = mysqli_query($connect, $query);

        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                $pendengar = mysqli_fetch_assoc($result)['pendengar'];
            } else {
                die("ERROR: No data found for the specified singer and album.");
            }
            mysqli_free_result($result);

            // Hitung hasil prediksi
            $hasil_prediksi = $a + $b * $pendengar;
            $hasil_prediksi = round($hasil_prediksi);

            // Cek jumlah penjualan saat ini dari database
            $query = "SELECT jumlah_penjualan FROM album WHERE nama_penyanyi = '$nama_penyanyi_prediksi' AND nama_album = '$nama_album_prediksi' AND tahun_penjualan = $tahun_prediksi";
            $result = mysqli_query($connect, $query);
            
            if ($result) {
                if (mysqli_num_rows($result) > 0) {
                    $current_sales = mysqli_fetch_assoc($result)['jumlah_penjualan'];
                } else {
                    $current_sales = 0; // Jika tidak ada data, anggap penjualan saat ini adalah 0
                }
                mysqli_free_result($result);

                // Hitung sisa stok
                $stok_sisa = $hasil_prediksi - $current_sales;

                // Saran berdasarkan perbandingan
                if ($stok_sisa > 0) {
                    $stok_saran = "Saran: Tambahkan stok penjualan album sebanyak " . $stok_sisa . " unit.";
                } else {
                    $stok_saran = "Saran: Jangan tambahkan stok penjualan album.";
                }

                // Simpan riwayat peramalan ke database
                $tahun_prediksi = (int) $tahun_prediksi;
                $hasil_prediksi = (float) $hasil_prediksi;

                $query = "INSERT INTO riwayat (tanggal_prediksi, nama_penyanyi_prediksi, nama_album_prediksi, tahun_prediksi, hasil_prediksi) VALUES (NOW(), '$nama_penyanyi_prediksi', '$nama_album_prediksi', $tahun_prediksi, $hasil_prediksi)";
                $result = mysqli_query($connect, $query);

                if (!$result) {
                    die("ERROR: Could not execute query: " . mysqli_error($connect));
                }
            } else {
                die("ERROR: Could not execute query: " . mysqli_error($connect));
            }
        } else {
            die("ERROR: Could not execute query: " . mysqli_error($connect));
        }
    }
}


$years = [];
$sales = [];
foreach ($data as $row) {
    $years[] = $row['pendengar'];
    $sales[] = $row['jumlah_penjualan'];
}

$forecast_years = range(min($years) - 1, max($years) + 1);
$forecast_sales = array_map(function($year) use ($a, $b) {
    return $a + $b * $year;
}, $forecast_years);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>StayCes</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/style2.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-success text-dark">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="user-dashboard.php">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user-tambah-album.php">Data Album</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="user-hasil-peramalan.php">Hasil Peramalan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user-history.php">Riwayat Peramalan</a>
                </li>
            </ul>
        </div>
        <a class="btn btn-outline-dark" href="logout.php" role="button">Keluar</a>
    </div>
</nav>

<div class="container mt-4">
    <h2>Hasil Peramalan</h2>
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tahun Penjualan</th>
                    <th>Nama Penyanyi</th>
                    <th>Nama Album</th>
                    <th>Jumlah Pendengar (x)</th>
                    <th>Jumlah Penjualan (y)</th>
                    <th>x^2</th>
                    <th>y^2</th>
                    <th>xy</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (!empty($data)) {
                    $no = 1;
                    foreach ($data as $row) {
                        echo "<tr>";
                        echo "<td>" . $no++ . "</td>";
                        echo "<td>" . htmlspecialchars($row['tahun_penjualan']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['nama_penyanyi']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['nama_album']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['pendengar']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['jumlah_penjualan']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['x_squared']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['y_squared']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['xy']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='8' class='text-center'>No data available</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <h3>Form Peramalan</h3>
        <form action="" method="POST">
            <div class="mb-3">
                <label for="nama_penyanyi_prediksi" class="form-label">Nama Penyanyi</label>
                <select class="form-select" id="nama_penyanyi_prediksi" name="nama_penyanyi_prediksi" required>
                    <option value="">Pilih Penyanyi</option>
                    <?php foreach ($penyanyi as $p): ?>
                        <option value="<?php echo htmlspecialchars($p); ?>"><?php echo htmlspecialchars($p); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="nama_album_prediksi" class="form-label">Nama Album</label>
                <select class="form-select" id="nama_album_prediksi" name="nama_album_prediksi" required>
                    <option value="">Pilih Album</option>
                    <?php foreach ($albums as $album): ?>
                        <option value="<?php echo htmlspecialchars($album); ?>"><?php echo htmlspecialchars($album); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="tahun_prediksi" class="form-label">Tahun yang Akan Diramalkan</label>
                <input type="number" class="form-control" id="tahun_prediksi" name="tahun_prediksi" required>
            </div>
            <button type="submit" class="btn btn-primary">Peramalkan</button>
        </form>

        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
            <div class="mt-4">
                <h4>Hasil Peramalan</h4>
                <?php if (isset($hasil_prediksi)): ?>
                    <p>Peramalan untuk tahun <strong><?php echo htmlspecialchars($tahun_prediksi); ?></strong> adalah: <strong><?php echo $hasil_prediksi; ?></strong></p>
                    <p><?php echo $stok_saran; ?></p>
                <?php else: ?>
                    <p>Terjadi kesalahan dalam perhitungan peramalan.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    

    <div class="mt-4">
        <h3>Grafik Data dan Peramalan</h3>
        <canvas id="forecastChart"></canvas>
    </div>
</div>

<script>
    // Ambil data dari PHP
    const years = <?php echo json_encode($years); ?>;
    const sales = <?php echo json_encode($sales); ?>;
    const forecastYears = <?php echo json_encode($forecast_years); ?>;
    const forecastSales = <?php echo json_encode($forecast_sales); ?>;

    // Konfigurasi grafik
    const ctx = document.getElementById('forecastChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: forecastYears,
            datasets: [
                {
                    label: 'Data Penjualan',
                    data: sales.map((value, index) => ({ x: years[index], y: value })),
                    borderColor: 'blue',
                    backgroundColor: 'rgba(0, 0, 255, 0.2)',
                    fill: false,
                },
                {
                    label: 'Peramalan',
                    data: forecastYears.map((year, index) => ({ x: year, y: forecastSales[index] })),
                    borderColor: 'red',
                    backgroundColor: 'rgba(255, 0, 0, 0.2)',
                    fill: false,
                }
            ]
        },
        options: {
            scales: {
                x: {
                    type: 'linear',
                    position: 'bottom'
                }
            }
        }
    });
</script>
</body>
</html>

