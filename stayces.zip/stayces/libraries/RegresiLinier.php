<?php

class RegresiLinier {
    private $x;
    private $y;
    private $slope;
    private $intercept;

    public function __construct($x, $y) {
        // Pastikan kedua array memiliki panjang yang sama
        if (count($x) !== count($y)) {
            throw new Exception('Panjang array tidak sama.');
        }

        // Pastikan semua elemen adalah numerik
        foreach ($x as $value) {
            if (!is_numeric($value)) {
                throw new TypeError('Nilai x harus numerik.');
            }
        }

        foreach ($y as $value) {
            if (!is_numeric($value)) {
                throw new TypeError('Nilai y harus numerik.');
            }
        }

        $this->x = $x;
        $this->y = $y;

        // Hitung koefisien regresi linier saat inisialisasi
        $this->calculate();
    }

    private function calculate() {
        // Perhitungan sederhana regresi linier
        $n = count($this->x);
        $sum_x = array_sum($this->x);
        $sum_y = array_sum($this->y);
        $sum_x_squared = array_sum(array_map(function($val) { return $val * $val; }, $this->x));
        $sum_xy = 0;

        for ($i = 0; $i < $n; $i++) {
            $sum_xy += $this->x[$i] * $this->y[$i];
        }

        // Hitung koefisien
        $this->slope = ($n * $sum_xy - $sum_x * $sum_y) / ($n * $sum_x_squared - $sum_x * $sum_x);
        $this->intercept = ($sum_y - $this->slope * $sum_x) / $n;
    }

    public function getCoefficients() {
        return array('slope' => $this->slope, 'intercept' => $this->intercept);
    }

    public function predict($x_value) {
        // Prediksi nilai y berdasarkan x_value
        if (!is_numeric($x_value)) {
            throw new TypeError('Nilai x harus numerik.');
        }

        return $this->slope * $x_value + $this->intercept;
    }
}

?>
