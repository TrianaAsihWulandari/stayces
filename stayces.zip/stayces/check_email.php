<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Periksa Email</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css" />
</head>
<body>
  <div class="container mt-5">
    <h2>Periksa Email Anda</h2>
    <p>Silakan cek email Anda untuk tautan verifikasi. Jika tidak ada di inbox, periksa folder spam.</p>
    <p><a href="index.php">Kembali ke halaman login</a></p>
  </div>
</body>
</html>
