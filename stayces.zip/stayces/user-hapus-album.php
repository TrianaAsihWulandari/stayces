<?php

require ('config/Database.php');

session_start();

if(!isset($_SESSION['username'])) {
   header('Location:index.php');
}

$connect = openConnection();

$id = $_GET['id'];

if(mysqli_query($connect, "DELETE FROM album WHERE album.id = '$id'")) {
   header('Location:user-tambah-album.php');
} else {
   header("Location:user-tambah-album.php?notify=error");
}