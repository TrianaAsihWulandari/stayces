<?php
require('config/Database.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['search'])) {
        $email_or_username = $_POST['email_or_username'];

        // Koneksi ke database
        $connect = openConnection();
        
        // Query untuk mendapatkan data user
        $query = "SELECT username, email, nama_toko FROM users WHERE username LIKE '%$email_or_username%' OR email LIKE '%$email_or_username%'";
        $result = mysqli_query($connect, $query);

        // Menyimpan hasil pencarian dalam array
        $users = [];
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $users[] = $row;
            }
        } else {
            $error_message = "Tidak ada data ditemukan.";
        }

        
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/signin.css">
    <title>Lupa Password</title>
</head>
<body class="text-center">
    <div class="container">
        <h2 class="mt-5">Lupa Password</h2>
        <form action="forgot-password.php" method="POST" class="login-email mt-4">
            <div class="input-group">
                <input type="text" placeholder="Email atau Username" name="email_or_username" required>
            </div>
            <div class="input-group">
                <button name="search" class="btn btn-primary">Cari Data</button>
            </div>
        </form>

        <?php if (isset($users) && count($users) > 0) { ?>
            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Nama Toko</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user) { ?>
                        <tr>
                            <td><?php echo $user['username']; ?></td>
                            <td><?php echo $user['email']; ?></td>
                            <td><?php echo $user['nama_toko']; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <p class="mt-3">Silahkan Kirimkan Pesan Lupa Password ke alamat email berikut : triana677898@gmail.com. Nantinya admin akan mengirimkan data anda.</p>
        <?php } elseif (isset($error_message)) { ?>
            <p class="text-danger mt-4"><?php echo $error_message; ?></p>
        <?php } ?>

        <p class="mt-3">Kembali ke <a href="index.php">Halaman Login</a></p>
    </div>
</body>
</html>
