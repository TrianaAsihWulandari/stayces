<?php
require('config/Database.php');
session_start();

$error = ''; // Variabel untuk menyimpan pesan error

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $nama_toko = $_POST['nama_toko'];
  $username = $_POST['username'];
  $email = $_POST['email']; // Ambil email dari form
  $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
  $role = 'user';

  $connect = openConnection();

  // Periksa apakah nama toko atau email sudah terdaftar
  $query = "SELECT * FROM users WHERE nama_toko = '$nama_toko' OR email = '$email'";
  $result = mysqli_query($connect, $query);

  if (mysqli_num_rows($result) > 0) {
    $error = "Nama Toko atau Email sudah terdaftar.";
  } else {
    // Jika tidak ada duplikasi, lakukan insert data
    $query = "INSERT INTO users (nama_toko, username, email, password, role) VALUES ('$nama_toko', '$username', '$email', '$password', '$role')";

    if (mysqli_query($connect, $query)) {
      header('Location: index.php');
      exit(); // Tambahkan exit untuk menghentikan eksekusi setelah redirect
    } else {
      $error = "Gagal mendaftar. Silakan coba lagi.";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Daftar</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css" />
  <script>
    function showAlert(message) {
      alert(message);
    }
  </script>
</head>
<body>
  <div class="container mt-5">
    <h2>Daftar</h2>
    <?php if (isset($error) && $error !== '') { echo "<script>showAlert('$error');</script>"; } ?>
    <form action="register.php" method="POST">
      <div class="mb-3">
        <label for="nama_toko" class="form-label">Nama Toko</label>
        <input type="text" class="form-control" id="nama_toko" name="nama_toko" required>
      </div>
      <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" class="form-control" id="username" name="username" required>
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" required>
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password" required>
      </div>
      <button type="submit" class="btn btn-primary">Daftar</button>
    </form>
    <p class="mt-3">Sudah punya akun? <a href="index.php">Login di sini</a></p>
  </div>
</body>
</html>
