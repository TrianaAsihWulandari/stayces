<?php
require('config/Database.php');
session_start();

// Membuka koneksi database
$connect = openConnection();

// Menjalankan query
$query = "SELECT username, password, nama_toko, role FROM users";
$result = mysqli_query($connect, $query);

// Memeriksa error query
if (!$result) {
    die("Query failed: " . mysqli_error($connect));
}

// Tutup koneksi
mysqli_close($connect);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>StayCes</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/js/bootstrap.min.js" integrity="sha512-1/RvZTcCDEUjY/CypiMz+iqqtaoQfAITmNSJY17Myp4Ms5mdxPS5UV7iOfdZoxcGhzFbOm6sntTKJppjvuhg4g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css" integrity="sha512-SbiR/eusphKoMVVXysTKG/7VseWii+Y3FdHrt0EpKgpToZeemhqHeZeLWLhJutz/2ut2Vw1uQEj2MbRF+TVBUA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-success">
    <div class="container-fluid">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="admin-dashboard.php">Beranda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="admin-users.php">Data User</a>
          </li>
          <li class="nav-item">
          <a class="nav-link" href="admin-album.php">Data Album</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="admin-history.php">Riwayat Peramalan</a>
          </li>
        </ul>
      </div>
      <a class="btn btn-outline-dark" href="logout.php" role="button">Keluar</a>
    </div>
  </nav>

  <div class="container mt-4">
    <h2>Tabel Data User</h2>
    <div class="table-responsive">
      <table class="table table-bordered table-striped">
          <tr>
            <th>No</th>
            <th>Username</th>
            <th>Password</th>
            <th>Role</th>
            <th>Nama Toko</th>
          </tr>
        </thead>
        <tbody>
          <?php
          if (mysqli_num_rows($result) > 0) {
              // Inisialisasi nomor urut
              $no = 1;
              
              // Output data setiap baris
              while ($row = mysqli_fetch_assoc($result)) {
                  echo "<tr>";
                  echo "<td>" . $no++ . "</td>";  // Menampilkan nomor urut
                  echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['password']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['role']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['nama_toko']) . "</td>";
                  echo "</tr>";
              }
          } else {
              echo "<tr><td colspan='5' class='text-center'>No data available</td></tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
