<?php
require('config/Database.php');
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit();
}

$connect = openConnection();

if ($connect === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Mendapatkan input pencarian
$search_penyanyi = isset($_GET['search_penyanyi']) ? mysqli_real_escape_string($connect, $_GET['search_penyanyi']) : '';
$search_album = isset($_GET['search_album']) ? mysqli_real_escape_string($connect, $_GET['search_album']) : '';
$search_tahun = isset($_GET['search_tahun']) ? mysqli_real_escape_string($connect, $_GET['search_tahun']) : '';

// Membangun query SQL
$query = "SELECT tanggal_prediksi, nama_penyanyi_prediksi, nama_album_prediksi, tahun_prediksi, hasil_prediksi 
          FROM riwayat 
          WHERE 1=1";

if ($search_penyanyi !== '') {
    $query .= " AND nama_penyanyi_prediksi LIKE '%$search_penyanyi%'";
}

if ($search_album !== '') {
    $query .= " AND nama_album_prediksi LIKE '%$search_album%'";
}

if ($search_tahun !== '') {
    $query .= " AND tahun_prediksi = $search_tahun";
}

$query .= " ORDER BY tanggal_prediksi DESC";

// Eksekusi query
$result = mysqli_query($connect, $query);

$history = [];
if ($result) {
    while ($obj = mysqli_fetch_object($result)) {
        $history[] = array(
            'tanggal_prediksi' => $obj->tanggal_prediksi,
            'nama_penyanyi_prediksi' => $obj->nama_penyanyi_prediksi,
            'nama_album_prediksi' => $obj->nama_album_prediksi,
            'tahun_prediksi' => (int) $obj->tahun_prediksi,
            'hasil_prediksi' => (float) $obj->hasil_prediksi
        );
    }
    mysqli_free_result($result);
} else {
    die("ERROR: Could not execute query: " . mysqli_error($connect));
}

mysqli_close($connect);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>StayCes</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/style2.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-success text-dark">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="user-dashboard.php">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user-tambah-album.php">Data Album</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user-hasil-peramalan.php">Hasil Peramalan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="user-history.php">Riwayat Peramalan</a>
                </li>
            </ul>
        </div>
        <a class="btn btn-outline-dark" href="logout.php" role="button">Keluar</a>
    </div>
</nav>

<div class="container mt-4">
    <h2>Riwayat Hasil Peramalan</h2>

    <!-- Formulir Pencarian -->
    <form action="" method="GET" class="mb-4">
        <div class="row">
            <div class="col-md-4">
                <input type="text" class="form-control" name="search_penyanyi" placeholder="Nama Penyanyi" value="<?php echo isset($_GET['search_penyanyi']) ? htmlspecialchars($_GET['search_penyanyi']) : ''; ?>">
            </div>
            <div class="col-md-4">
                <input type="text" class="form-control" name="search_album" placeholder="Nama Album" value="<?php echo isset($_GET['search_album']) ? htmlspecialchars($_GET['search_album']) : ''; ?>">
            </div>
            <div class="col-md-2">
                <input type="number" class="form-control" name="search_tahun" placeholder="Tahun" value="<?php echo isset($_GET['search_tahun']) ? htmlspecialchars($_GET['search_tahun']) : ''; ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary">Cari</button>
            </div>
        </div>
    </form>

    <!-- Tabel Riwayat Peramalan -->
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal Peramalan</th>
                    <th>Nama Penyanyi</th>
                    <th>Nama Album</th>
                    <th>Tahun yang Diramalkan</th>
                    <th>Hasil Peramalan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (!empty($history)) {
                    $no = 1;
                    foreach ($history as $row) {
                        echo "<tr>";
                        echo "<td>" . $no++ . "</td>";
                        echo "<td>" . htmlspecialchars($row['tanggal_prediksi']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['nama_penyanyi_prediksi']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['nama_album_prediksi']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['tahun_prediksi']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['hasil_prediksi']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center'>No data available</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
