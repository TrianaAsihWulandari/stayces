<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Pastikan untuk memasukkan autoloader Composer jika menggunakan Composer
require 'vendor/autoload.php';

class Mailer {
    private $mail;

    public function __construct() {
        $this->mail = new PHPMailer(true);
        
        try {
            // Server settings
            $this->mail->isSMTP();                                       // Set mailer to use SMTP
            $this->mail->Host       = 'localhost';                // Specify main and backup SMTP servers
            $this->mail->SMTPAuth   = true;                              // Enable SMTP authentication
            $this->mail->Username   = 'your_email@example.com';          // SMTP username
            $this->mail->Password   = 'your_email_password';             // SMTP password
            $this->mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;      // Enable TLS encryption, `ssl` also accepted
            $this->mail->Port       = 25;                               // TCP port to connect to

            // Recipients
            $this->mail->setFrom('no-reply@example.com', 'Your Website');
        } catch (Exception $e) {
            echo 'Mailer Error: ' . $this->mail->ErrorInfo;
        }
    }

    public function sendResetEmail($to, $resetLink) {
        try {
            $this->mail->addAddress($to);                               // Add a recipient

            $this->mail->isHTML(true);                                  // Set email format to HTML
            $this->mail->Subject = 'Reset Password Request';
            $this->mail->Body    = 'Klik tautan berikut untuk mengatur ulang password Anda: <a href="' . $resetLink . '">' . $resetLink . '</a>';

            $this->mail->send();
            echo 'Email telah dikirim';
        } catch (Exception $e) {
            echo 'Mailer Error: ' . $this->mail->ErrorInfo;
        }
    }
}

