<?php

function openConnection() {
  $host = 'localhost';
  $user = 'root';
  $pass = '';
  $db = 'stayces'; 

  //Membuat koneksi ke db
  $connection = new mysqli($host, $user, $pass, $db);


  if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
  }

  return $connection;
}
