-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 02, 2024 at 04:05 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stayces`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE `album` (
  `id` int(11) NOT NULL,
  `tahun_penjualan` varchar(50) NOT NULL,
  `nama_penyanyi` varchar(50) NOT NULL,
  `nama_album` varchar(50) NOT NULL,
  `versi_album` varchar(50) NOT NULL,
  `jumlah_penjualan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`id`, `tahun_penjualan`, `nama_penyanyi`, `nama_album`, `versi_album`, `jumlah_penjualan`) VALUES
(0, '2023', 'straykids', 'ate', 'Photobook', '1285');

-- --------------------------------------------------------

--
-- Table structure for table `comeback`
--

CREATE TABLE `comeback` (
  `id` int(11) NOT NULL,
  `bulan_rilis` varchar(50) NOT NULL,
  `nama_penyanyi` varchar(50) NOT NULL,
  `nama_agensi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `tanggal_prediksi` datetime NOT NULL,
  `nama_penyanyi_prediksi` varchar(50) NOT NULL,
  `tahun_prediksi` int(50) NOT NULL,
  `hasil_prediksi` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `tanggal_prediksi`, `nama_penyanyi_prediksi`, `tahun_prediksi`, `hasil_prediksi`) VALUES
(8, '2024-08-01 06:40:53', 'straykids', 2024, 1234),
(9, '2024-08-01 06:42:51', 'straykids', 2024, 1234),
(10, '2024-08-01 06:43:29', 'nmixx', 2025, 123),
(11, '2024-08-01 06:44:12', 'nmixx', 2025, 10511),
(12, '2024-08-01 08:34:46', 'nmixx', 2025, 10511),
(13, '2024-08-01 08:41:00', 'nmixx', 2025, 10511),
(14, '2024-08-01 09:07:59', 'nmixx', 2025, 10511),
(15, '2024-08-01 09:08:28', 'straykids', 2022, 7611),
(16, '2024-08-01 17:31:23', 'straykids', 2022, 7611);

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `id` int(11) NOT NULL,
  `nama_penyanyi` varchar(50) NOT NULL,
  `tahun_penjualan` year(4) NOT NULL,
  `jumlah_penjualan` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`id`, `nama_penyanyi`, `tahun_penjualan`, `jumlah_penjualan`) VALUES
(0, 'nmixx', '2023', 8578),
(1, 'straykids', '2020', 5678);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `nama_penyanyi` varchar(50) NOT NULL,
  `tahun_penjualan` int(50) NOT NULL,
  `jumlah_penjualan` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `nama_penyanyi`, `tahun_penjualan`, `jumlah_penjualan`) VALUES
(1, 'nmixx', 0, 4567),
(2, 'straykids', 0, 6789);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(10) NOT NULL,
  `nama_toko` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `nama_toko`) VALUES
(4, 'admin', '$2y$10$Gpsv5KiwpMXGPmDxLIlqrO.AuRBf6.YG7UMd24V53f0R0xzdEizYG', 'admin', 'abc'),
(5, 'user', '$2y$10$m7/4.PyOyxzdbtxF8mM67eKCMQjV6Ie/HeysutZ/5VCjDbJvoc1B6', 'user', 'dweakkishop');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comeback`
--
ALTER TABLE `comeback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album`
--
ALTER TABLE `album`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `comeback`
--
ALTER TABLE `comeback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
