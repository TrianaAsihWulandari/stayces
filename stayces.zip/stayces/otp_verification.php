<?php
require('config/Database.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $otp = $_POST['otp'];
    $username = $_SESSION['username']; // Assumed to be set during registration

    $connect = openConnection();
    $query = "SELECT otp FROM users WHERE username='$username' AND otp='$otp'";

    $result = mysqli_query($connect, $query);

    if (mysqli_num_rows($result) == 1) {
        $update_query = "UPDATE users SET is_verified=1 WHERE username='$username'";
        mysqli_query($connect, $update_query);
        header('Location: success.php'); // Redirect to success page
    } else {
        $error = "Invalid OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>OTP Verification</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css" />
</head>
<body>
  <div class="container mt-5">
    <h2>Verify OTP</h2>
    <?php if (isset($error)) { echo "<div class='alert alert-danger'>$error</div>"; } ?>
    <form action="otp_verification.php" method="POST">
      <div class="mb-3">
        <label for="otp" class="form-label">Enter OTP</label>
        <input type="text" class="form-control" id="otp" name="otp" required>
      </div>
      <button type="submit" class="btn btn-primary">Verify OTP</button>
    </form>
  </div>
</body>
</html>
